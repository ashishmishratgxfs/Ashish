package com.businesslogic;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;

/**
 * Session Bean implementation class bblogic
 */
@Stateful
@LocalBean
public class bblogic implements bblogicRemote {

    /**
     * Default constructor. 
     */
    public bblogic() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public void adduser(String login, String password) {
		// TODO Auto-generated method stub
		System.out.println(login +"," + password);
		
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
		System.out.println("Yes");
		
		
	}

}
