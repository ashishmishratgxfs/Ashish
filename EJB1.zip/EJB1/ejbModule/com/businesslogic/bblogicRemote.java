package com.businesslogic;

import javax.ejb.Remote;

@Remote
public interface bblogicRemote {
	
	public void adduser (String login, String password);
	public void delete ();
	

}
